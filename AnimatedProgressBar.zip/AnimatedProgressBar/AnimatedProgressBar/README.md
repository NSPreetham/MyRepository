# Progress Bar

The Animated Program Bar is designed to read contents from the endpoint "http://pb-api.herokuapp.com/bars" and render the value specified.
 It also has buttons whose values are also read dynamically. The buttons are used to increment and decrement the values of the progress bar. 


